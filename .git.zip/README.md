# hotel-booking
Another hotel booking wordpress plugin.

Framework(s)
WP Bones
